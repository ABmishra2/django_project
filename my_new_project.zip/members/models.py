from django.db import models
class Member(models.Model):
    firstname = models.CharField(max_length= 255)
    lastname = models.CharField(max_length=255)
    
    birthdate = models.IntegerField(null=True)
    birthmonth = models.IntegerField(null=True)
    birthyear = models.IntegerField(null = True)
    phoneno = models.IntegerField(null=True)
  

    def __str__(self):
        return f"{self.firstname} {self.lastname} "


# Create your models here.

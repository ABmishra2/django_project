from django.db import models

class Project(models.Model):
    project_name = models.CharField(max_length=100)
    project_description = models.TextField()
    Time_spent = models.IntegerField(null=True)
    project_status = models.CharField(max_length=100, null=True)
    project_start_date = models.DateField(null=True)
    project_end_date = models.DateField(null=True)
    project_leader = models.CharField(max_length=225)

    def __str__(self):
        return f"{self.project_leader} {self.project_name} "


# Create your models here.

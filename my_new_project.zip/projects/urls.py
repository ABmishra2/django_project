from django.urls import path
from . import views

urlpatterns = [
    path('', views.project, name='main'),
    path('project_list/', views.project_list, name='project'),
    path('project/project_details/<int:id>',views.project_details , name='project_details')
]
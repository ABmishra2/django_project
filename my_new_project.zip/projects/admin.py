from django.contrib import admin
from .models import Project

class projectAdmin(admin.ModelAdmin):
    list_display = ("project_name","project_leader")

admin.site.register(Project,projectAdmin)

# Register your models here.

from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from projects.models import Project
# Create your views here.

def project_list(request):
    projects = Project.objects.all().values()
    template = loader.get_template('project.html')
    context = {
        'projects': projects,
    }
    return HttpResponse(template.render(context, request))

def project_details(request,id):
    projects = Project.objects.get(id=id)
    template = loader.get_template('project_details.html')
    context = {
        'projects': projects,
    }
    return HttpResponse(template.render(context, request))

def project(request):

    return HttpResponse("Hello world!")
